import { PageRenderer } from "@/components/PageRenderer";

export default function AboutPage() {
  return <PageRenderer pageKey="about" />;
}
